// ELEC2645 Unit 2 Project Template
// Command Line Application Menu Handling Code

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include "funcs.h"

void circuit_calculator(void);
void quizs(void);
void explanation(void);
char get_grade(int score);

static void main_menu(void);
static void print_main_menu(void);
static int  get_user_input(void);
static void select_menu_item(int input);
static void go_back_to_main(void);
static int  is_integer(const char *s);

void circuit_calculator(void){
    int choice;
    float r1, r2, r3, v1,i1,r_total1,r_total2;
    printf("===circuit-calculator-assistant===\n");
    printf("1.calculator for series resistors\n");
    printf("2.calculator for parallel resistors\n");
    printf("3.the application of ohm's law\n");
    printf("0.exit\n");
    printf("please choose one(integral 0-3):\n");
    scanf("%d", &choice);
    switch (choice)
    {
        case 1:
            printf("Please input r1(ohm)\n");
            scanf("%f", &r1);
            printf("Please input r2(ohm)\n");
            scanf("%f", &r2);
            r_total1 = r1 + r2;
            printf("Total resistance of series resistors: %.2f ohm\n", r_total1);
            break;

        case 2:
            printf("Please input r1(ohm)\n");
            scanf("%f", &r1);
            printf("Please input r2(ohm)\n");
            scanf("%f", &r2);
            r_total2 = r1*r2/(r1 + r2);
            printf("Total resistance of parallel resistors: %.2f ohm\n", r_total2);
            break;
        case 3:
            printf("Please input v1(V)\n");
            scanf("%f",&v1);
            printf("Please input i1(A)\n");
            scanf("%f",&i1);
            r3=v1/i1;
            printf("The resistance is:%.2f ohm \n",r3);
            break;
        case 0:
            printf("quitting the calculator...");
            return;
        default:
            printf("Null choice, please choose again!\n");
            break;

    }
}
char get_grade(int score) {
    if (score >= 7) return 'A';
    else if (score >= 4) return 'B';
    else if (score >= 2) return 'C';
    else return 'D';
}
void quizs(void){
    int score=0;
    char answer1;
    char answer2;
    char answer3;
    char answer4;
    char answer5;
    char answer6;
    char answer7;
    char answer8;
    printf("***knowledge quizs module***\n");
    printf("1. What type of signal describes the containers' ability to hold electricity?\n");
    printf("A.Current B.Resistance C.Capacity D.Inductance\n");
    scanf(" %c",&answer1);
    getchar();
    const char correct_answer1='C';
    if (answer1=='Q'||answer1=='q')
    {
        printf("Quiz exited. You can try again!\n");
        return;
    }else if(answer1==correct_answer1||answer1=='c'){
        printf("Right! +1 point\n");
        score++;}
    else{
        printf("wrong! No point!\n");
    }
    printf("2. What is the relevantly safe voltage to human body?\n");
    printf("A. 3V   B. 36V   C. 12V   D. 72V\n");
    scanf("%c",&answer2);
    getchar();
    const char correct_answer2='B';
    if (answer2==correct_answer2||answer2=='b'){
        printf("Right! +1 point\n");
        score++;
    }
    else{
        printf("Wrong! No point\n");
    }

    printf("3.Which statement about kirchuhoff's law is true?\n");
    printf("A.KVL:current balance at node; KCL:voltage balance in loop.\n");
    printf("B.KVL:voltage balance in loop; KCL:current balance at node.\n");
    printf("C.KVL:current balance in loop; KCL:voltage balance at node.\n");
    printf("D.KVL:voltage balance at node; KCL:current balance in loop.\n");
    scanf(" %c",&answer3);
    getchar();
    const char correct_answer3='B';
    if (answer3==correct_answer3||answer3=='b')
    {
        printf("Right! +1 point\n");
        score++;
    }
    else{
        printf("wrong! No point!\n");
    }
    printf("4.According to Thevenin's Theorem, a linear active two-terminal network can be quivalently repalaced by a series of which two components?\n");
    printf("A. ideal current source and equivalent resistance\n");
    printf("B.ideal voltage source and equivalent resistance\n");
    printf("C.ideal current source and capacitor\n");
    printf("D.ideal vlotage source and inductor\n");
    scanf("%c",&answer4);
    getchar();
    const char correct_answer4='B';
    if (answer4==correct_answer4||answer4=='b'){
        printf("Right! +1 point\n");
        score++;
    }
    else{
        printf("wrong! No point!\n");
    }
    printf("5.For Norton's Theorem, any two-terminal network can be replaced by \n");
    printf("A.ideal current source and equivalent resistance\n");
    printf("B.ideal voltage source and equivalent resistance\n");
    printf("C.ideal current source and capacitor\n");
    printf("D.ideal vlotage source and inductor\n");
    scanf(" %c",&answer5);
    getchar();
    if (answer5=='A'||answer5=='a')
    {
        printf("Right! +1 point\n");
        score++;
    }
    else{
        printf("wrong! No point!\n");
    }
    printf("6.Maximum Power Transfer Theorem in DC Circuits:When would the load resistor receive the maxium power?\n");
    printf("A.RL=Req/2\n");
    printf("B.RL=Req/4\n");
    printf("C.RL=Req\n");
    printf("D.RL=2Req\n");
    scanf(" %c",&answer6);
    getchar();
      if (answer6=='C'||answer6=='c')
    {
        printf("Right! +1 point\n");
        score++;
    }
    else{
        printf("wrong! No point!\n");
    }
    printf("7. Numerical equation in Norton's Theorem?\n");
    printf("A.Uoc=Isc*Req\n");
    printf("B.Uoc=2Isc*Req\n");
    printf("C.Uoc=Isc*Req/2\n");
    printf("D.Uoc=Isc/Req\n");
    scanf(" %c",&answer7);
    getchar();
      if (answer7=='A'||answer7=='a')
    {
        printf("Right! +1 point\n");
        score++;
    }
    else{
        printf("wrong! No point!\n");
    }
    printf("8. Which of the following choice is the wrong form of Maxwell's equations?\n");
    printf("A.GradE=roy*epsilon0\n");
    printf("B.gradB=0\n");
    printf("C.grad*E=-dB/dt\n");
    printf("D.grad*B=mu0J+mu0*epsilon0*dE/dt\n");
    scanf(" %c",&answer8);
    getchar();
      if (answer8=='A'||answer8=='a')
    {
        printf("Right! +1 point\n");
        score++;
    }
    else{
        printf("wrong! No point!\n");
    }
    printf("Your total score is %d\n", score);
    char grade = get_grade(score);
    printf("Your grade is %c\n",grade);

}
void explanation(void){
    typedef struct {
        char term[20];
        char explanation[200];
    }circuit_term;
    circuit_term circuitterms[]={
        {"KCL","KCL states the sum of currents entering a node equals the sum leaving.\n"},
        {"KVL","KVL states the sum of voltages around a closed loop is zero.\n"},
        {"resistance","Resistance is the ability to oppose current.\n"},
        {"voltage","Voltage is the ability to transfer current.\n"},
        {"current","Current is the ability to carry electronics.\n"},
        {"electronic","Electronic is the substance that carry a unit of negative charge.\n"},
        {"charge","Charge is the amount of electricity that held by something.\n"},
        {"electricity", "Eletricity is a form of energy that power human life.\n"},
        {"inductance","Inductance is the ability to induct electronics.\n"},
        {"capacity","Capacity is the ability to hold electronics.\n"}
    };
    const int termcount=sizeof(circuitterms)/sizeof(circuitterms[0]);
    for (int i = 0; i < termcount; i++)
    {
        printf("%s\n",circuitterms[i].term);
    }
    printf("Please input a electronic term:(e.g. KCL,charge)(or q to exit)\n");
    char input_term[50];
    scanf("%s",input_term);
    if(strcmp(input_term,"q")==0){
        printf("Exiting...\n");
        return;
    }
    for(int i=0;i<termcount;i++)
    {
        if(strcmp(circuitterms[i].term,input_term)==0){
            printf("term:%s\nexplanation:%s\n", 
            circuitterms[i].term, 
            circuitterms[i].explanation);
            return;
        }
    }
    printf("Term %s is not found, please check the spelling!",input_term);
    /*int choice;
    printf("Please a random number(1-10):and 0 to exit");
    scanf("%d",&choice);
    for (int i=0;i<termcount;i++){
    getchar();
        if (choice>=1&&choice<=10){
        printf("Looking up...");
        int idx=choice-1;
        printf("Term:%s\nExplanation:%s",circuitterms[idx].term,circuitterms[idx].explanation);}
        else printf("Wrong! Please enter a int between 0-10.\n");
    }
    if (choice==0)
    {
        exit(0);
    }*/
    
}
static void main_menu(void)
{
    print_main_menu();
    int input = get_user_input();
    select_menu_item(input);
}

static void print_main_menu(void)
{
    printf("\n-----------AI-style assistant-----------\n");
    printf("\n"
           "\t1. Circuit calculator\n"
           "\t2. Circuits quizs\n"
           "\t3. Explanations of electronic jargons\n"
           "\t4. Exit\n");
    printf("\n----------------------------------------\n");
}
static int get_user_input(void)
{
    enum{MENU_ITEMS=4};
    char buf[128];
    int valid_input=0;
    int value=0;

    do {
        printf("\nSelect item (1-4):");
        if(!fgets(buf, sizeof(buf), stdin)) {
            puts("\nInput error. Exiting.");
            exit(1);
        }

        buf[strcspn(buf, "\r\n")] = '\0';

        if (!is_integer(buf)) {
            printf("Enter an integer!\n");
            valid_input = 0;
        } else {
            value = (int)strtol(buf, NULL, 10);
            if (value >= 1 && value <= MENU_ITEMS) {
                valid_input = 1;
            } else {
                printf("Invalid menu item!\n");
                valid_input = 0;
            }
        }
    } while (!valid_input);

    return value;
}

static void select_menu_item(int input)
{
    switch (input) {
        case 1:
            circuit_calculator();
            go_back_to_main();
            break;
        case 2:
            quizs();
            go_back_to_main();
            break;
        case 3:
            explanation();
            go_back_to_main();
            break;
        case 4:
        default:
            printf("Bye!\n");
            exit(0);
    }
}

static void go_back_to_main(void)
{
    char buf[64];

    do {
        printf("\nEnter 'b' or 'B' to go back to main menu: ");
        if (!fgets(buf, sizeof(buf), stdin)) {
            puts("\nInput error. Exiting.");
            exit(1);
        }
        buf[strcspn(buf, "\r\n")] = '\0'; /* strip newline */
    } while (!((buf[0] == 'b' || buf[0] == 'B') && buf[1] == '\0'));
}

static int is_integer(const char *s)
{
    if (!s || !*s) return 0;

    if (*s == '+' || *s == '-') s++;

    if (!isdigit((unsigned char)*s)) return 0;

    while (*s) {
        if (!isdigit((unsigned char)*s)) return 0;
        s++;
    }
    return 1;
}

int main(void) {

    for (;;) {
        main_menu();
    }

    return 0;
}